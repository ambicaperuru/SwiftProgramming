//
//  MovieCollectionViewCell.swift
//  CVMovieApp1
//
//  Created by Peruru,Ambica on 4/20/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    //Assign movies into the cell, after creating the number of cells dynamically.
    
    func assignMovie(movie: Movie){
        imageViewOL.image = movie.image
    }
}
